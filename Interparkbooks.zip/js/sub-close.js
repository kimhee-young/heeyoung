$(function () {
	$('.popclose').click(function (e) {
		$('.popup').hide();
	});
});